# Original Version (CSV-only import)
This folder mirrors the Excel datasets directly into two tables (CrimeData, StormData) with minimal changes.
- No indexes, no normalization, no foreign keys
- Simple SELECT queries only
-
