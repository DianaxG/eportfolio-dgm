# Enhanced Version (Normalized + Indexes)
This folder upgrades the Excel datasets into a normalized PostgreSQL schema with dimensions and a fact table.
- `schema_enhanced.sql`: creates schema/tables with FKs and indexes
- `queries_enhanced.sql`: example analytics queries
- `csv/`: CSV exports of the provided Excel files for ETL

Load path (psql):
\i sql/schema_enhanced.sql
-- then use your ETL or COPY to load csv/crime_data.csv and csv/storm_data.csv into staging tables,
-- transform to miami.dim_offense, miami.dim_location, miami.storm, and miami.incident.
